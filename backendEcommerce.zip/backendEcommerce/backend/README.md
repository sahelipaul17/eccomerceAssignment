# Ecommerce

ecommerce api which have login, register login -admin logout as basic user story . then we have product controller - router-model,category controller-router-model , cart-order controller-model-router, we are tracking wishlist , add to cart via token. with token we will able to use req.user .we have brand,blog,blog category , color and there controller -model-router . used multiple package for dependency purpo💺 

## mocha chai

 used for test cases. 
 allowing you to write tests involving asynchronous code without additional libraries or complex setups.

 ## express 

 methods to specify what function is called for a particular HTTP , helps with router and all

 ## express async handler


 middleware to handle async and error handling 

 ## jsonwebtoken

to create unique token for every user and and access their unique cart

## mongoose

mongoose is Object Data Modeling (ODM) library , it is use to handle mongoose request like connection and set for mongodb

## body-parser

to process data sent in an HTTP request body. It provides four express middleware for parsing JSON, Text, URL-encoded, and raw data sets over an HTTP request body

## bcrypt

simple password into fixed-length characters called a hash

## cookie-parser

parses cookies attached to the client request object. 

## cors

allows a server to indicate any origins (domain, scheme, or port) other than its own from which a browser should permit loading resources.


## dotenv

set key-value pair  as environment variables we can access them anywhere in the project by process.env.#️⃣ 


## morgan

log requests made to your Node. js server

## multer

handling multipart/form-data , which is primarily used for uploading files

## nodemailer

 you to send emails from your server with ease. 


## sharp

compresses images faster than most other Node. js modules,

## slugify

converts a string to a URL-friendly slug format.

## uniqid

identify entities 

## nodemon

 monitor project and restart server automatically after save 


