 // Endpoint testing with mocha and chai and chai-http

    // Import libraries 
    const chai = require('chai');
    const chaiHttp = require('chai-http');

    const should = chai.should();
    var mongoose = require("mongoose");

    // Import server
    var server = require('../index');

    // Import Todo Model   
    var Todo = require("../models/userModel");
server = 'http://localhost:5000'
    // use chaiHttp for making the actual HTTP requests   
    chai.use(chaiHttp);
    describe('user API', function() {
        beforeEach(function(done) {
            var newTodo = new Todo({
                text: 'Cook Indomie',
                status: true
            });
            newTodo.save(function(err) {
                done();
            });
        });

        afterEach(function(done) {
            Todo.collection.drop().then(function() {

                success     
            }).catch(function() {

              //  error handling
               console.warn(' collection may not exists!');
            })
            //done();
        });

        it('should list ALL Todos on /todos GET', function(done) {
            chai.request(server)
                .get('/todos')
                .end(function(err, res) {
                    res.should.have.status(200);
                    res.should.be.json;
                    res.body.should.be.a('array');
                    res.body[0].should.have.property('text');
                    res.body[0].should.have.property('status');
                    res.body[0].should.have.property('_id');
                    done();
                });
        });

        it('should register todo on /sign Up POST', function(done) {
            chai.request(server)
                .post('/api/v1/user/register')
                .send({
                    "firstname": "sa",
                    "lastname": "p",
                    "email": "abcd5e@gmail.com",
                    "password": "sahhed@123",
                    "role": "user",
                    "mobile":"8987567893"
                })
                .end(function(err, res) {

                    // the res object should have a status of 201
                    res.should.have.status(200);
                    res.should.be.json;
                    // res.body.should.be.a('object');
                    res.body.should.have.property('firstname');
                    res.body.should.have.property('email');
                    res.body.should.have.property('mobile');
                    res.body.isBlocked.should.equal(false);
                    // res.body.status.should.equal(true);
                    done();
                });
        });



        it('should login on /signin POST', function(done) {
            chai.request(server)
                .post('/api/v1/user/login')
                .send({
                    "email": "abcd5e@gmail.com",
                    "password": "sahhed@123",
                })
                .end(function(err, res) {

                    // the res object should have a status of 201
                    res.should.have.status(200);
                    res.should.be.json;
                    // res.body.should.be.a('object');
                    res.body.should.have.property('firstname');
                    res.body.should.have.property('email');
                    res.body.should.have.property('mobile');
                    res.body.should.have.property('token');
                    // res.body.isBlocked.should.equal(false);
                    // res.body.status.should.equal(true);
                    done();
                });
        });


        it('should login on /signin admin POST', function(done) {
            chai.request(server)
                .post('/api/v1/user/admin-login')
                .send({
                    "email": "abccd@gmail.com",
                    "password": "sahhed@123"
                })
                .end(function(err, res) {

                    // the res object should have a status of 201
                    res.should.have.status(200);
                    res.should.be.json;
                    // res.body.should.be.a('object');
                    res.body.should.have.property('firstname');
                    res.body.should.have.property('email');
                    res.body.should.have.property('mobile');
                    res.body.should.have.property('token');
                    done();
                });
        });

        it('should add a product on /cart POST', function(done) {
            chai.request(server)
                .post('/api/v1/user/cart')
                .send({
                    "cart":{
                         "_id": "64a6c413f131ce6dfce44cb2",
                         "count": 4,
                         "color": "white"
                    }
                })
                .end(function(err, res) {

                    // the res object should have a status of 201
                    res.should.have.status(200);
                    res.should.be.json;
                    // res.body.should.be.a('object');
                    res.body.should.have.property('cart');
                    // res.body.isBlocked.should.equal(false);
                    // res.body.status.should.equal(true);
                    done();
                });
        });
  
        it('should add a product on /cart/applycoupon POST', function(done) {
            chai.request(server)
                .post('/api/v1/user/cart/applycoupon')
                .send({
                    "coupon":"ER45FFGYYTT"
                })
                .end(function(err, res) {

                    // the res object should have a status of 201
                    res.should.have.status(200);
                    res.should.be.json;
                    // res.body.should.be.a('object');
                    res.body.should.have.property('coupon');
                    // res.body.isBlocked.should.equal(false);
                    // res.body.status.should.equal(true);
                    done();
                });
        });


        it('should add a product on /cart/cash-order POST', function(done) {
            chai.request(server)
                .post('/api/v1/user/cart/cash-order')
                .send({
                    "COD" : "1",
                    "couponApplied" : "1"
                })
                .end(function(err, res) {

                    // the res object should have a status of 201
                    res.should.have.status(200);
                    res.should.be.json;
                    // res.body.should.be.a('object');
                    res.body.should.have.property('COD');
                    // res.body.isBlocked.should.equal(false);
                    // res.body.status.should.equal(true);
                    done();
                });
        });





















        it('should update the status of a Todo on /todos/<id> PUT', function(done) {
            chai.request(server)
                .get('/todos')
                .end(function(err, res) {
                    chai.request(server)
                        .put('/todo/' + res.body[0]._id)

                        // this is like sending $http.post or this.http.post in Angular\
                        .send({
                            'text': 'Cook Indomie',
                            'status': false
                        })
                        // when we get a response from the endpoint
                        // in other words,
                        .end(function(error, response) {
                            // the res object should have a status of 200
                            response.should.have.status(200);
                            response.should.be.json;
                            response.body.should.be.a('object');
                            response.body.should.have.property('text');
                            response.body.should.have.property('status');
                            response.body.should.have.property('_id');
                            response.body.text.should.equal('Cook Indomie');
                            response.body.status.should.equal(false);
                            done();
                        });
                });
        });
        it('should delete a todo on /todo/<id> DELETE without Auth Token', function(done) {
            chai.request(server)
                .get('/todos')
                .end(function(err, res) {
                    chai.request(server)
                        .delete('/todo/' + res.body[0]._id)
                        .end(function(error, response) {
                            response.should.have.status(200);
                            response.body.should.have.property('message');
                            response.body.message.should.equal('Todo successfully deleted');
                            done();
                        });
                });
        });
    });
